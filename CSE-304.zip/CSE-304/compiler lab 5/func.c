#include<stdio.h>




char* newTemp(int i)
{

    char* str;
    char c = i + '0';
    ///printf("%c", c);
    str[0] = 't';
    str[1] = c;
    str[2] = '\n';


    return str;


}


int main()



{
    int n;
    scanf("%d", &n);

    char* x;
    x = newTemp(n);
    printf("%s", x);




}
