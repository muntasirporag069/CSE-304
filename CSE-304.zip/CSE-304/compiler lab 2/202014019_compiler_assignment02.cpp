#include<bits/stdc++.h>
#include <fstream>
using namespace std;


#define    dbg1(x)      cout << #x << " " << x << endl;
#define    dbg2(x, y)   cout << #x << " " << x << " " << #y << " " << y << endl;


/// symboltable class

class symbolinfo
{

public:
    string symbol;
    string category;
    string datatypeReturntype;

};


class rtrn
{

public:
    int index1;
    int index2;
};



int mx = -1;



class symboltable
{
public:


    vector<symbolinfo>v[10];

    int find_index(string str)
    {
        int sum = 0;
        for (int i=0; i<str.size(); i+=2)
        {
            int ascii = str[i];
            sum += ascii << 9LL;
        }

        return sum % 10;

    }



    void insert_into (string str1, string str2, string str3)
    {
        rtrn r1 = look_up(str1);
        if (r1.index1 == -1 or r1.index2 == -1)
        {
            int idx = find_index(str1);
            mx = max(mx, idx);
            dbg1(idx)
            int id = v[idx].size();
            symbolinfo s;
            s.symbol = str1;
            s.category = str2;
            s.datatypeReturntype = str3;
            v[idx].push_back(s);
            cout << "Inserted at position " << idx << " , " << id << endl;

        }
        else
        {
            cout << "Already in the symbol table" << endl;

        }
    }


    void print()
    {
        for (int i=0; i<=mx ; i++)
        {
            if (v[i].size())
            {
                cout << i << " -> " << "<";
                for (int j=0; j<v[i].size(); j++)
                {
                    cout << v[i][j].symbol << ", " << v[i][j].category << ", " << v[i][j].datatypeReturntype<< ">";
                    cout << " ";
                }
            }
            else
            {
                cout << i << " -> ";
            }
            cout << endl;
        }
    }


    rtrn look_up(string symboll)
    {
        bool flag = false;
        rtrn r;
        for (int i=0; i<=mx; i++)
        {
            for (int j=0; j<v[i].size(); j++)
            {
                if (v[i][j].symbol == symboll)
                {

                    r.index1 = i;
                    r.index2 = j;
                    flag = true;
                    break;
                }
            }
        }

        if (flag)
        {
            return r;
        }
        else
        {
            r.index1 = -1;
            r.index2 = -1;
            return r;
        }


    }



    rtrn delete_from (string tmp)
    {
        int idx = find_index(tmp);
        rtrn r2 = look_up(tmp);

        if (r2.index1 == -1 or r2.index2 == -1)
        {
            return r2;
        }
        else
        {
            r2.index1 = idx;

            for (int i=0; i<v[idx].size(); i++)
            {
                if (v[idx][i].symbol == tmp)
                {
                    auto it = v[idx].begin() + i;
                    v[idx].erase(it);
                    r2.index2 = i;
                    break;
                }
            }

            return r2;


        }
    }

};

/// symbol table class ends here

bool check_keyword(string str)
{
    if (str == "if" or str == "else" or str == "for" or str == "while" or str == "break" or str == "int" or str == "char" or str == "float" or str == "double" or str == "return" or str == "include")
    {
        return true;
    }
    else
    {
        return false;
    }
}








vector<pair<string,int>>vkeyword,vfunction,voperator,videntifier;

int main()
{

    string s;
    symboltable sb;

    map<string,string>mp;
    string last_word = "";

    ofstream myfile1("Function.txt");
    ofstream myfile2("Identifier.txt");
    ofstream myfile3("Keyword.txt");
    ofstream myfile4("Operator.txt");


    ifstream myfile("sample_input.txt"); /// reading from input file

    /// myfile1 << "hello world" << endl; writing in a file


    int line = 1;
    while (getline(myfile, s))
    {

        string temp = "";


        for (int i=0; i<s.size(); i++)
        {
            if ((s[i] >= 'a' and s[i] <= 'z') or (s[i] >= 'A' and s[i] <= 'Z') or (s[i] >= '0' and s[i] <= '9'))
            {
                temp += s[i];
            }
            else if (s[i] == '(')
            {
//                dbg1(temp);
                if(check_keyword(temp))
                {
                    cout << "pushed into keyword-->" << temp << " line-->" << line << endl;
                    sb.insert_into(temp,"KEYWORD","string");
                    sb.print();
                    vkeyword.push_back({temp,line});
                }
                else
                {
                    if(temp.size() > 0)
                    {
                        cout << "pushed into function-->" << temp << " line-->" << line << endl;
                        sb.insert_into(temp,"FUNCTION","string");
                        sb.print();
                        vfunction.push_back({temp,line});
                    }

                }
                last_word = temp;
                temp = "";
            }
            else if ((s[i] == '&' and s[i+1] == '&') or (s[i] == '|' and s[i+1] == '|') or (s[i] == '=' and s[i+1] == '=') or (s[i] == '!' and s[i+1] == '=') or (s[i] == '+' and s[i+1] == '=') or (s[i] == '-' and s[i+1] == '=') or (s[i] == '*' and s[i+1] == '=') or (s[i] == '/' and s[i+1] == '=') or (s[i] == '%' and s[i+1] == '='))
            {
                string str = "";
                str += s[i];
                str += s[i+1];
                i++;
                cout << "pushed into operator-->" << str << " line-->" << line << endl;
                sb.insert_into(str,"OPERATOR","string");
                sb.print();
                voperator.push_back({str,line});
            }
            else if(s[i] == '+' or s[i] == '-' or s[i] == '*' or s[i] == '/' or (s[i] == '%' and s[i+1] != 'd' and s[i+1] != 's' and s[i+1] != 'f' and s[i+1] != 'c') or s[i] == '!' or s[i] == '=')
            {
                cout << "pushed into operator-->" << s[i] << " line-->" << line << endl;
                string str = "";
                str += s[i];
                sb.insert_into(str,"OPERATOR","string");
                sb.print();
                voperator.push_back({str,line});

            }


            else
            {
//                dbg1(temp);
                if (check_keyword(temp))
                {
                    cout << "pushed into keyword-->" << temp << " line-->" << line << endl;
                    sb.insert_into(temp,"KEYWORD","string");
                    sb.print();
                    vkeyword.push_back({temp,line});
                }

                else
                {
//                    dbg1(temp.size())
                    if (temp.size() > 1 and s[i] != '.')
                    {
                        cout << "pushed into identifier-->" << temp << " line-->" << line << endl;
                        if (last_word == "int")
                        {
                            sb.insert_into(temp,"IDENTIFIER","Integer");
                        }
                        else
                        {
                            sb.insert_into(temp,"IDENTIFIER","String");
                        }
                        sb.print();
                        videntifier.push_back({temp,line});
                    }
                }
                last_word = temp;
                temp = "";
            }
        }
//        dbg2(temp,temp.size());
        if(temp.size() > 1)
        {
            if (check_keyword(temp))
            {
                cout << "pushed into keyword-->" << temp << " line-->" << line << endl;
                sb.insert_into(temp,"KEYWORD","string");
                sb.print();
                vkeyword.push_back({temp,line});
            }
            else
            {
                cout << "pushed into identifier-->" << temp << " line-->" << line << endl;
                if (last_word == "int")
                {
                    sb.insert_into(temp,"IDENTIFIER","Integer");
                }
                else
                {
                    sb.insert_into(temp,"IDENTIFIER","String");
                }
                sb.print();
                videntifier.push_back({temp,line});
            }
        }

        line++;
//        dbg1(line);

//        cout << "line break" << endl;

    }


    for (auto it : vkeyword)
    {
//        cout << " keyword " << it.first << " " << it.second << endl;
        myfile3 << it.first << " " << it.second << endl;
    }
    for (auto it : vfunction)
    {
//        cout << " function " << it.first << " " << it.second << endl;
        myfile1 << it.first << " " << it.second << endl;
    }
    for (auto it : videntifier)
    {
//        cout << " identifier " << it.first << " " << it.second << endl;
        myfile2 << it.first << " " << it.second << endl;
    }
    for (auto it : voperator)
    {
//        cout << " operator " << it.first << " " << it.second << endl;
        myfile4 << it.first << " " << it.second << endl;
    }





    myfile.close();

}
