#include<bits/stdc++.h>
using namespace std;

#define    dbg1(x)      cout << #x << " " << x << endl;
#define    dbg2(x, y)   cout << #x << " " << x << " " << #y << " " << y << endl;




class symbolinfo
{

public:
    string symbol;
    string category;
    string datatypeReturntype;

};


class rtrn
{

public:
    int index1;
    int index2;
};



int mx = -1;



class symboltable
{
public:


    vector<symbolinfo>v[10];

    int find_index(string str)
    {
        int sum = 0;
        for (int i=0; i<str.size(); i+=2)
        {
            int ascii = str[i];
            sum += ascii << 9LL;
        }

        return sum % 10;

    }



    void insert_into (string str1, string str2, string str3)
    {
        rtrn r1 = look_up(str1);
        if (r1.index1 == -1 or r1.index2 == -1)
        {
            int idx = find_index(str1);
            mx = max(mx, idx);
            dbg1(idx)
            int id = v[idx].size();
            symbolinfo s;
            s.symbol = str1;
            s.category = str2;
            s.datatypeReturntype = str3;
            v[idx].push_back(s);
            cout << "Inserted at position " << idx << " , " << id << endl;

        }
        else
        {
            cout << "Already in the symbol table" << endl;

        }
    }


    void print()
    {
        for (int i=0; i<=mx ; i++)
        {
            if (v[i].size())
            {
                cout << i << " -> " << "<";
                for (int j=0; j<v[i].size(); j++)
                {
                    cout << v[i][j].symbol << ", " << v[i][j].category << ", " << v[i][j].datatypeReturntype<< ">";
                    cout << " ";
                }
            }
            else
            {
                cout << i << " -> ";
            }
            cout << endl;
        }
    }


    rtrn look_up(string symboll)
    {
        bool flag = false;
        rtrn r;
        for (int i=0; i<=mx; i++)
        {
            for (int j=0; j<v[i].size(); j++)
            {
                if (v[i][j].symbol == symboll)
                {

                    r.index1 = i;
                    r.index2 = j;
                    flag = true;
                    break;
                }
            }
        }

        if (flag)
        {
            return r;
        }
        else
        {
            r.index1 = -1;
            r.index2 = -1;
            return r;
        }


    }



    rtrn delete_from (string tmp)
    {
        int idx = find_index(tmp);
        rtrn r2 = look_up(tmp);

        if (r2.index1 == -1 or r2.index2 == -1){
            return r2;
        }
        else{
        r2.index1 = idx;

        for (int i=0; i<v[idx].size(); i++){
            if (v[idx][i].symbol == tmp){
                auto it = v[idx].begin() + i;
                v[idx].erase(it);
                r2.index2 = i;
                break;
            }
        }

        return r2;


    }
    }

};


int main()
{

    char command;
    symboltable sb;
    while (cin >> command)
    {

        if (command == 'I')
        {

            int type;
            cin >> type;

            if (type == 1)
            {
                int number; /// for storing number
                cin >> number;
                string strreturn;
                cin >> strreturn;
                string x = to_string(number);
                sb.insert_into(x, strreturn, "1"); /// storing the number after turning it into string
            }

            else if (type == 2)
            {
                string strreturn, strdatatype, symbl;
                cin >> strreturn >> symbl >> strdatatype;
                sb.insert_into(symbl,strdatatype, strreturn); /// storing the strings
            }

        }

        else if (command == 'P')
        {
            sb.print();
        }

        else if (command == 'L')
        {
            string to_be_find;
            cin >> to_be_find;
            rtrn rt = sb.look_up(to_be_find);
            if (rt.index1 == -1 or rt.index2 == -1)
            {
                cout << "Symbol not found in the symbol table" << endl;
            }
            else
            {
                cout << "Found at " << rt.index1 << ", " << rt.index2 << endl;
            }

        }

        else if (command == 'D')
        {
            string to_be_deleted;
            cin >> to_be_deleted;
            rtrn rss = sb.delete_from(to_be_deleted);
            if (rss.index1 == -1 or rss.index2 == -1)
            {
                cout << "Symbol not found in the symbol table" << endl;
            }
            else
            {
                cout << "Deleted from " << rss.index1 << ", " << rss.index2 << endl;
            }
        }
    }

}


/*
I
2
void
print
FUNCTION
I
1
231
NUMBER
I
2
char
a
IDENTIFIER
I
2
string
if
KEYWORD
P
L
231
L
123
L
print
L
a
L
c
P
D
231
D
123
P
*/

